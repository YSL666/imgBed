bug:
  1.当返回首页时菜单栏子项不会移除激活事件，并折叠

优化:
  1.Home.vue 的 el-menu 中 :default-active 但以防以后出bug暂时不用$route.path进行绑定

疑惑:
  1.Login.vue 请求登录时，在 http.js 中的 axios.post 请求参数不用写{}，
    而 Users.vue 获取用户列表在 http.js 中的 axios.get 请求参数要写{}
  2.输入框验证与视频不同，视频验证成功为绿色边框，实际无