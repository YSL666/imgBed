import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login'
import Home from '../views/Home'

Vue.use(VueRouter)

const routes = [{
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import( /* webpackChunkName: "Home" */ '../views/Home'),
    redirect: '/welcome',
    children: [{
      path: '/welcome',
      name: 'Welcome',
      component: () => import( /* webpackChunkName: "Welcome" */ '../components/Welcome.vue')
    }, {
      path: '/users',
      name: 'Users',
      component: () => import( /* webpackChunkName: "Users" */ '../components/user/Users.vue')
    }]
  },
]

// 创建 router 实例，然后传 `routes` 配置
const router = new VueRouter({
  routes
})

// 挂载路由导航守卫
router.beforeEach((to, from, next) => {
  // to 将要访问的路径
  // from 代表从哪个路劲跳转进来
  // next 是个函数,代表放行 next()放行 next('login)强制跳转

  // 控制登录权限逻辑
  // 1.通过token判断用户是否登录
  // 2.无token强制跳转登录界面
  const tokenStr = window.sessionStorage.getItem('token')

  if (tokenStr) {
    if (to.path === '/login') {
      next({
        path: '/home'
      })
    } else {
      next()
    }
  } else {
    next();
  }
})

export default router