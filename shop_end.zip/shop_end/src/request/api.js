import {
  get,
  post,
  put,
  deleted
} from './http.js'
// 登录接口
export const apiLogin = (params) => post('login', params);
// 菜单列表获取接口
export const apiMenuList = () => get('menus');
// 用户数据列表获取接口
export const apiUserList = (params) => get('users', params);
// 修改用户状态接口
export const apiUserStateChange = (url) => put(url);
// 添加用户接口
export const apiAddUser = (params) => post('users', params);
// 编辑用户信息获取接口
export const apiEditUser = (id) => get(`users/${id}`);
// 修改用户信息接口
export const apiUpdataUser = (id, params) => put(`users/${id}`, params);
// 删除用户信息接口
export const apiDeleteaUser = (id) => deleted(`users/${id}`);