<template>
  <el-container class="home-container">
    <!-- 头部区域 -->
    <el-header>
      <div>
        <img src="@/assets/logo.png" alt="" />
        <span>电商后台管理系统</span>
      </div>
      <el-button type="info" @click="logout">退出</el-button>
    </el-header>
    <!-- 页面主体区域 -->
    <el-container>
      <!-- 侧边栏 -->
      <!-- 根据是否进行折叠菜单来动态设置宽度 -->
      <el-aside :width="isCollapse ? '64px' : '200px'">
        <div class="toggle-button" @click="toggleCollapse">|||</div>
        <!-- 侧边栏菜单区域 -->
        <!-- unique-opened 是否保持全部子菜单的展开-->
        <!-- :collapse 是否水平折叠收起菜单-->
        <!-- :collapse-transition 是否开启折叠动画 -->
        <!-- router 是否使用 vue-router 的模式，启用该模式会在激活导航时以 index 作为 path 进行路由跳转 -->
        <!-- :default-active 当前激活菜单的 index -->
        <el-menu
          background-color="#333744"
          text-color="#fff"
          active-text-color="#409EFF"
          unique-opened
          :collapse="isCollapse"
          :collapse-transition="false"
          router
          :default-active="activePath"
        >
          <!-- 一级菜单 -->
          <el-submenu
            :index="item.id + ''"
            v-for="item in menuList"
            :key="item.id"
          >
            <!-- 一级菜单模板区域 -->
            <template slot="title">
              <!-- 图标 -->
              <i :class="iconObj[item.id]"></i>
              <!-- 文本 -->
              <span>{{ item.authName }}</span>
            </template>
            <!-- 二级菜单 -->
            <!-- 循环渲染二级菜单 -->
            <el-menu-item
              :index="'/' + subItem.path"
              v-for="subItem in item.children"
              :key="subItem.id"
              @click="saveNavState('/' + subItem.path)"
            >
              <template slot="title">
                <!-- 图标 -->
                <i class="el-icon-s-grid"></i>
                <!-- 文本 -->
                <span>{{ subItem.authName }}</span>
              </template>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 右部内容 -->
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { apiMenuList } from '../request/api.js';
export default {
  name: 'Home',
  mounted() {
    // 获取左侧菜单逻辑
    // 通过接口获取数据，判断状态码，将数据放到 data()中
    apiMenuList().then((res) => {
      if (res.meta.status !== 200) return this.$message.error(res.meta.msg);
      this.menuList = res.data;
    });
    // 当加载完成时，获取激活状态的地址，因为一旦刷新后就会初始化数据
    this.activePath = window.sessionStorage.getItem('activePath');
  },
  data() {
    return {
      menuList: [],
      // 定义个图标仓库，通过数据id循环让一级菜单获得图标
      iconObj: {
        125: 'iconfont icon-user',
        103: 'iconfont icon-tijikongjian',
        101: 'iconfont icon-shangpin',
        102: 'iconfont icon-danju',
        145: 'iconfont icon-baobiao',
      },
      // 菜单是否折叠
      isCollapse: false,
      // 被激活的链接地址
      activePath: '',
    };
  },
  methods: {
    // 退出功能实现逻辑
    // 销毁本地的token并跳转登录页面即可,当访问其他页面时必须重新登录获得新的token才能访问
    logout() {
      window.sessionStorage.removeItem('token');
      // 顺便销毁本地的菜单的点击状态
      window.sessionStorage.removeItem('activePath');
      this.$router.push('/login');
    },
    // 切换菜单的折叠与展开
    toggleCollapse() {
      this.isCollapse = !this.isCollapse;
    },
    // 当用户点击时，保存链接的激活状态地址到sessionStorage中，并赋值给data的activePath用于动态绑定
    saveNavState(activePath) {
      window.sessionStorage.setItem('activePath', activePath);
      this.activePath = activePath;
    },
  },
};
</script>

<style lang="scss" scoped>
.home-container {
  height: 100%;
}
.el-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-left: 0;
  font-size: 20px;
  color: #fff;
  background-color: #373d41;
  > div {
    img {
      height: 60px;
    }
    span {
      margin-left: 15px;
    }
  }
}
.el-aside {
  background-color: #333744;
  .toggle-button {
    color: #fff;
    background-color: #4a5064;
    line-height: 24px;
    font-size: 10px;
    text-align: center;
    letter-spacing: 0.2em;
    cursor: pointer;
  }
  .el-menu {
    border-right: 0;
  }
  .iconfont {
    margin-right: 10px;
  }
}
.el-main {
  background-color: #eaedf1;
}
</style>