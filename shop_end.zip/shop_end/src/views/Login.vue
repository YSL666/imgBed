<template>
  <div class="login">
    <div class="login_box">
      <!-- 登录头像区 -->
      <div class="login_img">
        <img src="../assets/logo.png" alt="" />
      </div>
      <!-- 登录表单区 -->
      <!-- :model绑定表单对象 :rules表单验证规则 ref获取组件信息-->
      <el-form
        :model="loginForm"
        :rules="loginFormRules"
        ref="loginFormRef"
        class="login_form"
      >
        <!-- 用户名 -->
        <el-form-item prop="username">
          <!-- prefix-icon 在输入框前面显示icon图标 -->
          <el-input
            v-model="loginForm.username"
            prefix-icon="iconfont icon-morentouxiang"
          ></el-input>
        </el-form-item>
        <!-- 密码 -->
        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            type="password"
            prefix-icon="iconfont icon-lock_fill"
          ></el-input>
        </el-form-item>
        <!-- 按钮区域 -->
        <div class="login_btns">
          <el-button type="primary" @click="login">登录</el-button>
          <el-button type="info" @click="resetForm('loginFormRef')"
            >重置</el-button
          >
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
import { apiLogin } from '../request/api.js';
export default {
  name: 'Login',
  data() {
    return {
      loginForm: {
        username: '',
        password: '',
      },
      // 表单验证规则逻辑
      // 1.在 el-form 中设置 :rules 表单校验规则
      // 2.在表单校验规则中写校验规则
      // 3.在 el-form-item 中设置 prop 接到对应的校验规则
      loginFormRules: {
        // 验证用户名
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' },
        ],
        // 验证密码
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          {
            min: 6,
            max: 11,
            message: '长度在 6 到 11 个字符',
            trigger: 'blur',
          },
        ],
      },
    };
  },
  methods: {
    // 重置表单逻辑
    // 1.在 el-form 中添加 ref 属性进行标记，用来获取元素或子组件注册的引用信息
    // 2.为按钮添加点击事件，将 ref 属性获取表单实例传入
    // 3.在点击事件中，用 $refs 获取注册在父组件的引用信息，用 resetFields() 进行重置
    resetForm(loginFormRefName) {
      // this指向vue
      this.$refs[loginFormRefName].resetFields();
    },
    // 登录预验证
    // 1.获取表单实例，调用 validate() 对整个表单进行校验，返回的是boolean
    login() {
      this.$refs.loginFormRef.validate((vali) => {
        if (!vali) return;
        // 判断登录是否请求成功
        apiLogin(this.loginForm).then((res) => {
          if (res.meta.status !== 200) {
            this.$message.error('登录失败');
            return;
          }
          this.$message.success('登录成功');
          // 登录成功后逻辑
          // 1.将登录成功后的token,保存到客户端的sessionStorage中,因为token只在当前网站打开期间生效
          // 2.项目中除了登录以外的API接口,必须登录之后才能访问
          // 3.通过编程式导航跳转到后台主页
          window.sessionStorage.setItem('token', res.data.token);
          this.$router.push('/home');
        });
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.login {
  height: 100%;
  background-color: #2b4b6b;
}

.login_box {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 450px;
  height: 300px;
  transform: translate(-50%, -50%);
  background-color: #fff;
  border-radius: 3px;
  .login_img {
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    height: 130px;
    width: 130px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 50%;
    background-color: #fff;
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #ccc;
    }
  }
}

.login_form {
  margin-top: 20%;
  padding: 0 20px;
  .login_btns {
    display: flex;
    justify-content: flex-end;
  }
}
</style>
