<template>
  <div>
    <!-- 面包屑导航区域 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
      <el-breadcrumb-item>用户列表</el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 卡片视图区域 -->
    <el-card>
      <!-- 第一行 -->
      <!-- :gutter栅格间隔 -->
      <el-row :gutter="20">
        <!-- 第一列 -->
        <!-- :span栅格占据的列数 -->
        <el-col :span="7">
          <!-- 搜索区域 -->
          <!-- clearable 显示清空按钮 -->
          <!-- @clear 自带的点击清除按钮触发的事件 -->
          <el-input
            placeholder="请输入内容"
            clearable
            v-model="queryUserInfo.query"
            @clear="getUserList('clear')"
          >
            <el-button
              slot="append"
              icon="el-icon-search"
              @click="getUserList('query')"
            ></el-button>
          </el-input>
        </el-col>
        <!-- 第二列 -->
        <!-- 添加用户区域 -->
        <el-col :span="4">
          <el-button type="primary" @click="addDialogVisible = true"
            >添加用户</el-button
          >
        </el-col>
      </el-row>

      <!-- 用户列表区域 -->
      <!-- :data 数据源 stripe 斑马纹，隔行变色 border 竖线边框-->
      <el-table :data="userList" stripe border>
        <!-- label 显示的标题 -->
        <!-- prop 对应列内容的字段名，来自于数据源对象中的键名key -->
        <!-- type 对应列的类型，index为索引 -->
        <el-table-column label="索引" type="index"></el-table-column>
        <el-table-column label="姓名" prop="username"></el-table-column>
        <el-table-column label="邮箱" prop="email"></el-table-column>
        <el-table-column label="电话" prop="mobile"></el-table-column>
        <el-table-column label="角色" prop="role_name"></el-table-column>
        <el-table-column label="状态">
          <!-- v-solt 统一了插槽写法，#为缩写 #插槽名="名字任意，接取子组件标签slot上属性数据的集合，所有动态绑定的属性" -->
          <!-- .row 在Element官网的Table中的Slot有写 获取行数据  -->
          <!-- @change switch 状态发生变化时的回调函数 -->
          <template #default="state">
            <el-switch
              v-model="state.row.mg_state"
              @change="userStateChanged(state.row)"
            >
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template #default="operation">
            <!-- 消息提示框 -->
            <!-- effect	默认提供的主题 content 显示的内容 placement 出现位置 -->
            <!-- :enterable 鼠标是否可进入到 tooltip 中 -->
            <el-tooltip
              effect="dark"
              content="编辑"
              placement="top"
              :enterable="false"
            >
              <!-- 编辑按钮 -->
              <el-button
                type="primary"
                icon="el-icon-edit"
                size="mini"
                @click="showEditDialog(operation.row.id)"
              ></el-button>
            </el-tooltip>
            <el-tooltip
              effect="dark"
              content="分配权限"
              placement="top"
              :enterable="false"
            >
              <el-button
                type="warning"
                icon="el-icon-setting"
                size="mini"
              ></el-button>
            </el-tooltip>
            <el-tooltip
              effect="dark"
              content="删除"
              placement="top"
              :enterable="false"
            >
              <el-button
                type="danger"
                icon="el-icon-delete"
                size="mini"
                @click="removeUserById(operation.row.id)"
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页区域 -->
      <!-- :page-sizes 选择每次显示多少数据 layout 选择分页的功能 -->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryUserInfo.pagenum"
        :page-sizes="[1, 2, 5, 10]"
        :page-size="queryUserInfo.pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>

      <!-- 添加用户对话框 -->
      <!-- 添加关闭对话后触发的事件 -->
      <el-dialog
        title="添加用户"
        :visible.sync="addDialogVisible"
        width="50%"
        @close="addDialogClosed"
      >
        <!-- 内容主题区域 -->
        <el-form
          :model="addForm"
          :rules="addFormRules"
          ref="addFormRef"
          label-width="70px"
        >
          <el-form-item label="用户名" prop="username">
            <el-input v-model="addForm.username"></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="password">
            <el-input v-model="addForm.password"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="addForm.email"></el-input>
          </el-form-item>
          <el-form-item label="手机" prop="mobile">
            <el-input v-model="addForm.mobile"></el-input>
          </el-form-item>
        </el-form>
        <!-- 内容底部区域 -->
        <span slot="footer" class="dialog-footer">
          <el-button @click="addDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addUser">确 定</el-button>
        </span>
      </el-dialog>

      <!-- 修改用户的对话框 -->
      <el-dialog
        title="修改用户"
        :visible.sync="editDialogVisible"
        width="50%"
        @close="editFormClosed"
      >
        <el-form
          :model="editForm"
          :rules="editFormRules"
          ref="editFormRef"
          label-width="70px"
        >
          <el-form-item label="用户">
            <el-input v-model="editForm.username" disabled></el-input>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="editForm.email"></el-input>
          </el-form-item>
          <el-form-item label="手机号" prop="mobile">
            <el-input v-model="editForm.mobile"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="editDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="editUserInfo">确 定</el-button>
        </span>
      </el-dialog>
    </el-card>
  </div>
</template>


<script>
import {
  apiEditUser,
  apiAddUser,
  apiUserList,
  apiUserStateChange,
  apiUpdataUser,
  apiDeleteaUser,
} from '@/request/api.js';
export default {
  name: 'users',
  data() {
    // 验证邮箱的自定义规则
    // rule规则 value传入的值 callback回调函数，用于跳出验证
    let checkEmail = (rule, value, callback) => {
      // 验证邮箱的正则
      const regEmail =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (regEmail.test(value)) {
        // 合法邮箱
        return callback();
      }
      callback(new Error('请输入合法的邮箱'));
    };
    // 验证手机号码的自定义规则
    let checkMobile = (rule, value, callback) => {
      const regPhone =
        /^(?:(?:\+|00)86)?1(?:(?:3[\d])|(?:4[5-79])|(?:5[0-35-9])|(?:6[5-7])|(?:7[0-8])|(?:8[\d])|(?:9[189]))\d{8}$/;
      if (regPhone.test(value)) {
        return callback();
      }
      callback(new Error('请输入合法的手机号'));
    };

    return {
      // 获取用户列表的参数配置对象
      queryUserInfo: {
        // 搜索关键字
        query: '',
        // 当前页数
        pagenum: 1,
        // 当前每页显示多少数据
        pagesize: 2,
      },
      // 用户列表展示逻辑
      // 请求接口获取的数据保存到 data 中，
      userList: [],
      // 总数据条数
      total: 0,
      // 控制添加用户对话框的显示和隐藏
      addDialogVisible: false,
      // 添加用户的表单信息
      addForm: {
        username: '',
        password: '',
        email: '',
        mobile: '',
      },
      // 添加用户验证规则
      addFormRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          {
            min: 3,
            max: 10,
            message: '长度在 3 到 10 个字符之间',
            trigger: 'blur',
          },
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          {
            min: 3,
            max: 10,
            message: '长度在 3 到 10 个字符之间',
            trigger: 'blur',
          },
        ],
        email: [
          { required: true, message: '请输入邮箱', trigger: 'blur' },
          // 自定义规则
          { validator: checkEmail, trigger: 'blur' },
        ],
        mobile: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: checkMobile, trigger: 'blur' },
        ],
      },
      // 控制修改用户对话框的显示和隐藏
      editDialogVisible: false,
      // 查询得到的用户信息对象
      editForm: {},
      // 添加展示修改用户对话框的规则
      editFormRules: {
        email: [
          { require: true, message: '请输入用户邮箱', trigger: 'blur' },
          { validator: checkEmail, trigger: 'blur' },
        ],
        mobile: [
          { require: true, message: '请输入用户手机号', trigger: 'blur' },
          { validator: checkMobile, trigger: 'blur' },
        ],
      },
    };
  },
  created() {
    this.getUserList();
  },
  methods: {
    getUserList(flag) {
      // 通过传递标记符来解决搜索时当前页查询值为空的bug
      if (flag === 'clear' || flag === 'query') {
        this.queryUserInfo.pagenum = 1;
      }
      // 获取用户数据
      apiUserList(this.queryUserInfo).then((res) => {
        if (res.meta.status !== 200) {
          return this.$message.error('获取用户列表失败');
        }
        this.userList = res.data.users;
        this.total = res.data.total;
      });
    },
    // 监听 当前每页显示多少数据 改变的事件，传入新的显示数据的多少
    handleSizeChange(newSize) {
      this.queryUserInfo.pagesize = newSize;
      this.getUserList();
    },
    // 监听 页码值 改变的事件，传入新的页码值
    handleCurrentChange(newPage) {
      this.queryUserInfo.pagenum = newPage;
      this.getUserList();
    },
    // 修改用户状态
    userStateChanged(userInfo) {
      apiUserStateChange(
        `users/${userInfo.id}/state/${userInfo.mg_state}`
      ).then((res) => {
        if (res.meta.status != 200) {
          // 当用户更新失败时，页面会状态会改变，这时要取反修改回来，保证页面状态没有变化
          userInfo.mg_state = !userInfo.mg_state;
          return this.$message.error('更新用户状态失败');
        }
        return this.$message.success('更新用户状态成功');
      });
    },
    // 通过ref获取表单信息,调用提供的方法进行清除输入框
    addDialogClosed() {
      this.$refs.addFormRef.resetFields();
    },
    // 点击按钮，添加新用户
    addUser() {
      // 通过ref获取表单信息,调用提供的方法进行表单预验证，如果合法就发送添加用户的请求
      this.$refs.addFormRef.validate((valid) => {
        if (!valid) return;
        // 验证通过就发起添加用户的请求
        apiAddUser(this.addForm).then((res) => {
          if (res.meta.status != 201) {
            return this.$message.error('添加用户失败');
          }
          this.$message.success('添加用户成功');
          // 隐藏添加用户的对话框
          this.addDialogVisible = false;
          // 重新获取用户列表数据
          this.getUserList();
        });
      });
    },
    // 展示编辑用户的对话框
    showEditDialog(id) {
      // 获取用户数据展示在对话框上
      apiEditUser(id).then((res) => {
        if (res.meta.status !== 200) {
          return this.$message.error('查询用户信息失败');
        }
        this.editForm = res.data;
        this.editDialogVisible = true;
      });
    },
    // 监听修改用户对话框的关闭事件
    editFormClosed() {
      this.$refs.editFormRef.resetFields();
    },
    // 修改用户信息并提交
    editUserInfo() {
      // 进行表单的预验证
      this.$refs.editFormRef.validate((valid) => {
        if (!valid) return;
        // 发起修改用户信息的数据请求
        apiUpdataUser(this.editForm.id, {
          email: this.editForm.email,
          mobile: this.editForm.mobile,
        }).then((res) => {
          console.log(res);
          if (res.meta.status !== 200) {
            return this.$message.error('更新用户信息失败');
          }
          // 关闭对话框
          this.editDialogVisible = false;
          // 刷新数据列表
          this.getUserList();
          // 提示修改成功
          this.$message.success('更新用户信息成功');
        });
      });
    },
    // 根据id删除对应的用户信息
    removeUserById(id) {
      this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          apiDeleteaUser(id).then((res) => {
            if (res.meta.status !== 200) {
              return this.$message.error('删除用户失败');
            }
            this.$message.success('删除成功!');
            this.getUserList();
          });
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          });
        });
    },
  },
};
</script>

<style lang="scss" scoped>
</style>