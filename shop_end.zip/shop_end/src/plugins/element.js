import Vue from 'vue';
// Message导入弹框提示组件
import {
  Button,
  Form,
  FormItem,
  Input,
  Row,
  Col,
  Message,
  Container,
  Header,
  Aside,
  Main,
  Menu,
  Submenu,
  MenuItem,
  Breadcrumb,
  BreadcrumbItem,
  Card,
  Table,
  TableColumn,
  Switch,
  Tooltip,
  Pagination,
  Dialog,
  MessageBox
} from 'element-ui';

let componets = [Button,
  Form,
  FormItem,
  Input,
  Row,
  Col,
  Container,
  Header,
  Aside,
  Main,
  Menu,
  Submenu,
  MenuItem,
  Breadcrumb,
  BreadcrumbItem,
  Card,
  Table,
  TableColumn,
  Switch,
  Tooltip,
  Pagination,
  Dialog
]
componets.map(item => {
  Vue.use(item)
})

// 将弹框提示组件挂载到Vue原型链上
Vue.prototype.$message = Message;
Vue.prototype.$confirm = MessageBox.confirm;